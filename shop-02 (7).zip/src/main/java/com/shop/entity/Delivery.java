package com.shop.entity;

import com.shop.constant.OrderStatus;
import com.shop.dto.DeliveryDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity //이 클래스를 엔티티로 선언
@Table(name="Delivery") //엔티티와 매핑할 테이블을 지정
@Getter
@Setter
@ToString
public class Delivery extends BaseEntity{

    @Id
    @Column(name="delivery_id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String deliveryName;

    private String deliveryZipcode;

    private String deliveryStreetAdr;

    private String deliveryDetailAdr;

    private String deliveryDetail;

    private String deliveryAccount;

    private String deliveryAccountName;

    private String deliveryPhone;


}
