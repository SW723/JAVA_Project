package com.shop.constant;

public enum QnaStatus {
    WAITING, REPLIED
}
