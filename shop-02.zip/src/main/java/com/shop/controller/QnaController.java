package com.shop.controller;

import com.shop.constant.QnaStatus;
import com.shop.dto.ItemFormDto;
import com.shop.dto.MemberFormDto;
import com.shop.dto.QnaDto;
import com.shop.entity.Member;
import com.shop.entity.Qna;
import com.shop.service.QnaService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.persistence.EntityNotFoundException;
import javax.validation.Valid;
import java.util.List;

@RequestMapping("/qna")
@Controller
@RequiredArgsConstructor
public class QnaController {

    private final QnaService qnaService;

    @GetMapping(value = "/new")
    public String qnaForm(Model model) {
        model.addAttribute("qnaDto", new QnaDto());

        return "qna/qnaForm";
    }

    @PostMapping(value = "/new")
    public String qnaNew(@Valid QnaDto qnaDto, BindingResult bindingResult,
                         Model model){
        if(bindingResult.hasErrors()){
            return "qna/qnaForm";
        }
        try{
            qnaService.saveQna(qnaDto);
        } catch (Exception e){
            model.addAttribute("errorMessage","吏덈Ц ?깅줉 以??먮윭媛 諛쒖깮?섏??듬땲??");
            return "qna/qnaForm";
        }
        return "redirect:/qna/list";
    }

    @GetMapping(value = "/list")
    public String qnaList(Model model) {
        model.addAttribute("qnaList", qnaService.qnaList());
        return "qna/qnaList";
    }

    @GetMapping(value = "/list/{id}")
    public String qnaDtl(Model model, @PathVariable("id") Long id){
        QnaDto qnaDto = qnaService.getQnaDtl(id);
        model.addAttribute("qna", qnaDto);
        return "qna/qnaDtl";
    }

    @GetMapping(value = "/list/delete")
    public String qnaDelete(Long id){
        qnaService.qnaDelete(id);

        return "redirect:/qna/list";
    }

    @GetMapping(value = "/admin")
    public String qnaMng(Model model) {
        model.addAttribute("qnaList", qnaService.qnaList());
        return "qna/qnaMng";
    }

    @GetMapping(value = "/admin/delete")
    public String qnaMngDelete(Long id){
        qnaService.qnaDelete(id);

        return "redirect:/qna/admin";
    }

    @GetMapping(value = "/admin/{id}")
    public String qnaMngDtl(Model model, @PathVariable("id") Long id) {
        QnaDto qnaDto = qnaService.getQnaDtl(id);
        model.addAttribute("qna", qnaDto);

        return "qna/qnaAdminForm";
    }
/*
    @PostMapping(value = "/admin/{id}")
    public String qnaUpdate(@Valid QnaDto qnaDto, BindingResult bindingResult, Model model){
        if(bindingResult.hasErrors()){
            return "qna/qnaAdminForm";
        }
        try{
            qnaService.updateQna(qnaDto);
        } catch (Exception e){
            model.addAttribute("errorMessage","?듬? ?깅줉 以??먮윭媛 諛쒖깮?섏??듬땲??");
            return "qna/qnaAdminForm";
        }

        return "redirect:/qna/admin";
    }
*/

    @PostMapping(value = "/admin/{id}")
    public String qnaUpdate(@Valid QnaDto qnaDto, BindingResult bindingResult, Model model){
        if(bindingResult.hasErrors()){
            return "qna/qnaAdminForm";
        }
        try{
            qnaService.updateQna(qnaDto);
        } catch (Exception e){
            model.addAttribute("errorMessage","?듬? ?깅줉 以??먮윭媛 諛쒖깮?섏??듬땲??");
            return "qna/qnaAdminForm";
        }

        return "redirect:/qna/admin";
    }
}
