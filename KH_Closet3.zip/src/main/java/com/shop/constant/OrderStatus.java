package com.shop.constant;

public enum OrderStatus {
    FINAL, ORDER, CANCEL
}
