package com.shop.service;

import com.shop.dto.DeliveryDto;
import com.shop.entity.Delivery;
import com.shop.entity.Member;
import com.shop.entity.Qna;
import com.shop.repository.DeliveryRepository;
import com.shop.repository.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
@RequiredArgsConstructor
public class DeliveryService {

    private final MemberRepository memberRepository;

    private final DeliveryRepository deliveryRepository;



    public Long saveDelivery(DeliveryDto deliveryDto) throws Exception{

        Delivery delivery = deliveryDto.createDelivery();


        return deliveryRepository.save(delivery).getId();


    }
}
