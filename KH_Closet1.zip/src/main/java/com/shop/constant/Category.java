package com.shop.constant;

public enum Category {

    COAT, JACKET, T, KNIT, PANTS, SKIRT, DRESS, HAT, ACC
}
