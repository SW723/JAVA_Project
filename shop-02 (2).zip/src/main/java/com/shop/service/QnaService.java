package com.shop.service;

import com.shop.constant.QnaStatus;
import com.shop.dto.ItemFormDto;
import com.shop.dto.QnaDto;
import com.shop.entity.*;
import com.shop.repository.MemberRepository;
import com.shop.repository.QnaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.thymeleaf.util.StringUtils;

import javax.persistence.EntityNotFoundException;
import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class QnaService {

    @Autowired
    private final QnaRepository qnaRepository;

    @Transactional(readOnly = true)
    public QnaDto getQnaDtl(Long id) {

        Qna qna = qnaRepository.findById(id).get();
        QnaDto qnaDto = QnaDto.of(qna);

        return qnaDto;
    }

    public Qna saveQna(Qna qna) throws Exception {
        return qnaRepository.save(qna);
    }
/*
    public long updateQna(QnaDto qnaDto) throws Exception{
        Qna qna = qnaRepository.findById(qnaDto.getId()).orElseThrow(EntityNotFoundException::new);
        qna.updateQna(qnaDto);
        return qna.getId();
    }
*/

    public long updateQna(QnaDto qnaDto) throws Exception{
        Qna qna = qnaRepository.findById(qnaDto.getId()).orElseThrow(EntityNotFoundException::new);
        qna.updateQna(qnaDto);

        return qna.getId();
    }

    public List<Qna> qnaList(){
        return qnaRepository.findAll();
    }

    public void qnaDelete(Long id){
        qnaRepository.deleteById(id);
    }
}